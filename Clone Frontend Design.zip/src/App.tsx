import { useMemo, useState } from "react"

type Student = {
  name: string
  course: string
  score: number
  attendance: number
  studyHours: number
  risk: "Low Risk" | "Medium Risk" | "High Risk"
}

const students: Student[] = [
  {
    name: "Dara",
    course: "Python",
    score: 85,
    attendance: 90,
    studyHours: 12,
    risk: "Low Risk",
  },
  {
    name: "Sophea",
    course: "Statistics",
    score: 68,
    attendance: 75,
    studyHours: 8,
    risk: "Medium Risk",
  },
  {
    name: "Vuthy",
    course: "Python",
    score: 45,
    attendance: 50,
    studyHours: 3,
    risk: "High Risk",
  },
  {
    name: "Malis",
    course: "Database",
    score: 92,
    attendance: 95,
    studyHours: 15,
    risk: "Low Risk",
  },
  {
    name: "Rithy",
    course: "Web App",
    score: 58,
    attendance: 60,
    studyHours: 5,
    risk: "High Risk",
  },
  {
    name: "Sreyneang",
    course: "Database",
    score: 91,
    attendance: 94,
    studyHours: 14,
    risk: "Low Risk",
  },
  {
    name: "Chan",
    course: "Python",
    score: 72,
    attendance: 80,
    studyHours: 9,
    risk: "Medium Risk",
  },
  {
    name: "Bopha",
    course: "Statistics",
    score: 62,
    attendance: 88,
    studyHours: 7,
    risk: "Medium Risk",
  },
]

const navItems = ["Home", "Dashboard", "Student Data", "Risk Checker", "About"]

function SelectField({
  label,
  value,
  options,
  onChange,
}: {
  label: string
  value: string
  options: string[]
  onChange: (value: string) => void
}) {
  return (
    <label className="select-field">
      <span>{label}</span>
      <span className="select-wrap">
        <select
          value={value}
          onChange={(event) => onChange(event.target.value)}
        >
          {options.map((option) => (
            <option key={option}>{option}</option>
          ))}
        </select>
        <img src="/assets/3d3be.svg" alt="" />
      </span>
    </label>
  )
}

function RangeField({
  label,
  value,
  onChange,
}: {
  label: string
  value: number
  onChange: (value: number) => void
}) {
  return (
    <label className="range-field">
      <span>{label}</span>
      <span
        className="range-value"
        style={{ left: `calc(${value}% - ${value * 0.16}px)` }}
      >
        {value}
      </span>
      <input
        type="range"
        min="0"
        max="100"
        value={value}
        aria-label={label}
        onChange={(event) => onChange(Number(event.target.value))}
        style={{ "--range-progress": `${value}%` } as React.CSSProperties}
      />
    </label>
  )
}

function ScoreChart({ data }: { data: Student[] }) {
  const sorted = [...data].sort((a, b) => a.name.localeCompare(b.name))

  return (
    <div className="chart">
      <div className="chart-grid score-grid">
        {[100, 80, 60, 40, 20, 0].map((tick) => (
          <div className="grid-line" key={tick}>
            <img src="/assets/f7869.svg" alt="" />
            <span>{tick}</span>
          </div>
        ))}
        <div className="bars score-bars">
          {sorted.map((student) => (
            <div className="bar-column" key={student.name}>
              <span
                className="dynamic-bar score-bar"
                style={{ height: `${student.score}%` }}
                title={`${student.name}: ${student.score}`}
              />
              <span className="bar-label">{student.name}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function RiskChart({ data }: { data: Student[] }) {
  const risks: Student["risk"][] = ["High Risk", "Low Risk", "Medium Risk"]
  const counts = risks.map(
    (risk) => data.filter((student) => student.risk === risk).length,
  )

  return (
    <div className="chart">
      <div className="chart-grid risk-grid">
        {[3, 2, 1, 0].map((tick) => (
          <div className="grid-line" key={tick}>
            <img src="/assets/4aac5.svg" alt="" />
            <span>{tick}</span>
          </div>
        ))}
        <div className="bars risk-bars">
          {risks.map((risk, index) => (
            <div className="bar-column" key={risk}>
              <span
                className={`dynamic-bar risk-bar risk-bar-${index}`}
                style={{ height: `${(counts[index] / 3) * 100}%` }}
                title={`${risk}: ${counts[index]}`}
              />
              <span className="bar-label">{risk}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default function App() {
  const [activePage, setActivePage] = useState("Dashboard")
  const [course, setCourse] = useState("All")
  const [risk, setRisk] = useState("All")
  const [minimumAttendance, setMinimumAttendance] = useState(0)
  const [minimumScore, setMinimumScore] = useState(0)
  const [showDataset, setShowDataset] = useState(true)
  const [menuOpen, setMenuOpen] = useState(false)

  const filtered = useMemo(
    () =>
      students.filter(
        (student) =>
          (course === "All" || student.course === course) &&
          (risk === "All" || student.risk === risk) &&
          student.attendance >= minimumAttendance &&
          student.score >= minimumScore,
      ),
    [course, risk, minimumAttendance, minimumScore],
  )

  const averageScore = filtered.length
    ? (
        filtered.reduce((total, student) => total + student.score, 0) /
        filtered.length
      ).toFixed(2)
    : "0.00"
  const averageAttendance = filtered.length
    ? (
        filtered.reduce((total, student) => total + student.attendance, 0) /
        filtered.length
      ).toFixed(1)
    : "0.0"
  const highRiskCount = filtered.filter(
    (student) => student.risk === "High Risk",
  ).length
  const activeFilterCount = [
    course !== "All",
    risk !== "All",
    minimumAttendance > 0,
    minimumScore > 0,
  ].filter(Boolean).length

  function resetFilters() {
    setCourse("All")
    setRisk("All")
    setMinimumAttendance(0)
    setMinimumScore(0)
  }

  function downloadCsv() {
    const header = "Student Name,Course,Score,Attendance,Study Hours,Risk Level"
    const rows = filtered.map((student) =>
      [
        student.name,
        student.course,
        student.score,
        student.attendance,
        student.studyHours,
        student.risk,
      ].join(","),
    )
    const url = URL.createObjectURL(
      new Blob([[header, ...rows].join("\n")], { type: "text/csv" }),
    )
    const link = document.createElement("a")
    link.href = url
    link.download = "filtered-student-data.csv"
    link.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-inner">
          <div className="brand">
            <span className="brand-mark">E</span>
            <span>
              <strong>EduRisk</strong>
              <small>Student Intelligence</small>
            </span>
          </div>
          <p className="field-label">Workspace</p>
          <nav aria-label="Select page">
            {navItems.map((item) => (
              <button
                className={`nav-item ${activePage === item ? "active" : ""}`}
                type="button"
                key={item}
                onClick={() => setActivePage(item)}
              >
                <span className="nav-icon" aria-hidden="true">
                  {item.slice(0, 1)}
                </span>
                {item}
              </button>
            ))}
          </nav>
          <div className="sidebar-status">
            <span className="status-dot" />
            <span>
              <strong>Data synced</strong>
              <small>8 student records</small>
            </span>
          </div>
        </div>
      </aside>

      <div className="page">
        <header className="topbar">
          <div className="topbar-context">
            <span>Overview</span>
            <strong>{activePage}</strong>
          </div>
          <button
            type="button"
            className="deploy-button primary-button"
            onClick={downloadCsv}
          >
            Export report
          </button>
          <div className="menu-area">
            <button
              type="button"
              className="menu-button"
              aria-label="Main menu"
              aria-expanded={menuOpen}
              onClick={() => setMenuOpen((open) => !open)}
            >
              <img src="/assets/ee6ac.svg" alt="" />
            </button>
            {menuOpen && (
              <div className="menu-popover">
                <button type="button" onClick={() => setMenuOpen(false)}>
                  Settings
                </button>
                <button type="button" onClick={() => setMenuOpen(false)}>
                  Help
                </button>
              </div>
            )}
          </div>
        </header>

        <main>
          <section className="intro">
            <div>
              <span className="eyebrow">PERFORMANCE OVERVIEW</span>
              <h2>Student risk dashboard</h2>
              <p>
                Monitor performance, attendance, and risk signals across your
                active courses.
              </p>
            </div>
            <div className="intro-summary">
              <span className="live-dot" />
              Live dataset
            </div>
          </section>

          <section className="filter-card" aria-label="Dashboard filters">
            <div className="section-heading compact">
              <div>
                <span className="eyebrow">FILTERS</span>
                <h3>Refine the cohort</h3>
              </div>
              <button
                className="text-button"
                type="button"
                disabled={!activeFilterCount}
                onClick={resetFilters}
              >
                Reset filters
              </button>
            </div>
            <div className="filters">
              <SelectField
                label="Course"
                value={course}
                options={["All", "Python", "Statistics", "Database", "Web App"]}
                onChange={setCourse}
              />
              <SelectField
                label="Risk level"
                value={risk}
                options={["All", "Low Risk", "Medium Risk", "High Risk"]}
                onChange={setRisk}
              />
              <RangeField
                label="Minimum attendance"
                value={minimumAttendance}
                onChange={setMinimumAttendance}
              />
              <RangeField
                label="Minimum score"
                value={minimumScore}
                onChange={setMinimumScore}
              />
            </div>
            <div className="filter-footer">
              <span>
                Showing <strong>{filtered.length}</strong> of {students.length}{" "}
                students
              </span>
              {activeFilterCount > 0 && (
                <span className="filter-chip">
                  {activeFilterCount} active{" "}
                  {activeFilterCount === 1 ? "filter" : "filters"}
                </span>
              )}
            </div>
          </section>

          <section className="metrics-section">
            <div className="section-heading">
              <div>
                <span className="eyebrow">AT A GLANCE</span>
                <h3>Key metrics</h3>
              </div>
              <span className="section-note">Based on current filters</span>
            </div>
            <div className="metrics">
              <div className="metric-card metric-students">
                <div className="metric-top">
                  <span>Students</span>
                  <span className="metric-icon">ST</span>
                </div>
                <strong>{filtered.length}</strong>
                <small>{students.length} enrolled in total</small>
              </div>
              <div className="metric-card metric-score">
                <div className="metric-top">
                  <span>Average score</span>
                  <span className="metric-icon">SC</span>
                </div>
                <strong>{averageScore}</strong>
                <small>Out of 100 points</small>
              </div>
              <div className="metric-card metric-attendance">
                <div className="metric-top">
                  <span>Attendance</span>
                  <span className="metric-icon">AT</span>
                </div>
                <strong>{averageAttendance}%</strong>
                <small>Average attendance rate</small>
              </div>
              <div className="metric-card metric-risk">
                <div className="metric-top">
                  <span>High risk</span>
                  <span className="metric-icon">HR</span>
                </div>
                <strong>{highRiskCount}</strong>
                <small>
                  {filtered.length
                    ? Math.round((highRiskCount / filtered.length) * 100)
                    : 0}
                  % of filtered students
                </small>
              </div>
            </div>
          </section>

          <section className="charts-section">
            <div className="section-heading">
              <div>
                <span className="eyebrow">INSIGHTS</span>
                <h3>Performance patterns</h3>
              </div>
              <span className="section-note">Updated with your filters</span>
            </div>
            <div className="charts">
              <div className="chart-panel">
                <div className="chart-heading">
                  <div>
                    <h4>Student scores</h4>
                    <p>Individual performance out of 100</p>
                  </div>
                  <span className="legend legend-score">Score</span>
                </div>
                <ScoreChart data={filtered} />
              </div>
              <div className="chart-panel">
                <div className="chart-heading">
                  <div>
                    <h4>Risk distribution</h4>
                    <p>Students grouped by current risk level</p>
                  </div>
                  <span className="legend">Cohort</span>
                </div>
                <RiskChart data={filtered} />
              </div>
            </div>
          </section>

          <section className="dataset-section">
            <div className="section-heading dataset-heading">
              <div>
                <span className="eyebrow">STUDENT DATA</span>
                <h3>Students at a glance</h3>
                <p>{filtered.length} records match the current view</p>
              </div>
              <div className="dataset-actions">
                <label className="dataset-toggle">
                  <input
                    type="checkbox"
                    checked={showDataset}
                    onChange={(event) => setShowDataset(event.target.checked)}
                  />
                  <span className="custom-checkbox">
                    {showDataset && <img src="/assets/46628.svg" alt="" />}
                  </span>
                  Show table
                </label>
                <button
                  className="download-button"
                  type="button"
                  onClick={downloadCsv}
                >
                  Download CSV
                </button>
              </div>
            </div>
            {showDataset && (
                <div className="table-scroll">
                  <table>
                    <thead>
                      <tr>
                        <th aria-label="Row number" />
                        <th>Student Name</th>
                        <th>Course</th>
                        <th>Score</th>
                        <th>Attendance</th>
                        <th>Study Hours</th>
                        <th>Risk Level</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filtered.map((student, index) => (
                        <tr key={student.name}>
                          <td>{index}</td>
                          <td>{student.name}</td>
                          <td>{student.course}</td>
                          <td>{student.score}</td>
                          <td>{student.attendance}</td>
                          <td>{student.studyHours}</td>
                          <td>
                            <span
                              className={`risk-badge ${student.risk.toLowerCase().replaceAll(" ", "-")}`}
                            >
                              {student.risk}
                            </span>
                          </td>
                        </tr>
                      ))}
                      {!filtered.length && (
                        <tr>
                          <td className="empty-state" colSpan={7}>
                            No students match these filters.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
            )}
          </section>
        </main>
      </div>
    </div>
  )
}
